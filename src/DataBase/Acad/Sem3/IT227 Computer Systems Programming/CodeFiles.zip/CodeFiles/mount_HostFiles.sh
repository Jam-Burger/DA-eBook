sudo mount -t vboxsf, SharedFiles /home/ubuntu20sp/HostFiles/ -o rw,uid=ubuntu20sp,gid=ubuntu20sp

#Install guest edition
#https://linuxconfig.org/virtualbox-install-guest-additions-on-ubuntu-20-04-lts-focal-fossa