#!/usr/bin/bash
# #! = sha-bang
#Jenil Patel 202101074


echo 
# last_name='Patel'
# name="Jenil $last_name"
# echo "Hello $name"
# echo


#echo Shell = $SHELL
#echo Path = $PATH
#echo Home = $HOME
#echo User = $USER
#echo PWD = $PWD
#echo HostName = $HOSTNAME


<<COMMENT_JENIL
Jenil Patel
Multiline comments can be done like this
COMMENT_JENIL


# # $* and $@ parameter list
# $0 - File Name
# $i - i'th Parameter
# argName="$@"
# echo Hello $argName


# say_hi() {
#     echo "$0 is saying hello to $@"
# }
# say_hi "$@"


# say_hi2() {
#     local first_name="$1"
#     echo "$0 is saying hello to $first_name"
# }
# say_hi2 "$1"
# say_hi2 "$2"
# say_hi2 "$3"


# if [[...]]; then
#     ...
# fi


# if [[...]]
# then
#     ...
# fi


say_hi3() {
    local allArg=$@
    echo "Hi $allArg"
}
# if [[ -z "$@" ]]; then
#     echo "Provide something you Kanjus"
# elif [ -e $2 ]; then
#     echo "Just one ARG!"
# else
#     say_hi3 "$@"
# fi

for name in "$@"; do
    say_hi3 $name
done